import { BrowserRouter as Router, Route, Routes } from 'react-router-dom'
import AggiungiAsta from './screen/AggiungiAsta'
import DettaglioAsta from './screen/DettaglioAsta'
import ListeAsta from './screen/ListeAsta'
import ModificaAsta from './screen/ModificaAsta'

const App = () => {
  return (
    <Router>
      <Routes>
        <Route path='/addAsta' element={<AggiungiAsta />} />
        <Route path='/listeAste' element={<ListeAsta />} />
        <Route path='/asta/edit/:id' element={<ModificaAsta />} />
        <Route path='/asta/:id' element={<DettaglioAsta />} />
      </Routes>
    </Router>
  )
}

export default App