import React, { useState, useEffect } from 'react'
import axios from 'axios';
import {Container, Row, Col} from 'react-bootstrap'
import BigliettoAsta from '../component/BigliettoAsta';

const ListeAste = () => {


    const [aste, setAste] = useState([])

    useEffect(() => {
        const getAsteData = async () => {
            const { data } = await axios.get('/api/aste/allAsta')
            console.log(data)
            setAste(data)
        }
        getAsteData()
    }, [])

    return (
        <>
           <Container  className="justify-content-center p-2">
               <h1 className='text-center'>Liste Aste</h1>
               <hr />

               <Row>
                    {
                        aste.map(asta => {
                            return <Col md={6} lg={4} sm={12} key={asta.id}>
                                <BigliettoAsta asta={asta} />
                            </Col>
                        })
                    }
               </Row>


           </Container>

           
        </>
    )
}

export default ListeAste
