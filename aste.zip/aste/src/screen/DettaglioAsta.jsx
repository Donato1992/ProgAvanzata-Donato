import React, { useEffect, useState } from 'react'
import {Card, Button, Container, Form, Row, Col} from 'react-bootstrap'
import { Link } from 'react-router-dom'
import { useParams } from 'react-router'
import axios from 'axios'
import { useNavigate } from "react-router-dom";


const AstaDettaglio = () => {

    const { id } = useParams()
    const navigate=useNavigate()

    //Variabili per l'Asta
    const [title, setTitle] = useState('')
    const [price, setPrice] = useState(0)
    const [astedescription, setAstaDescription] = useState('')
    const [published, setPublished] = useState(true)
    const [bidTime, setBidTime] = useState(new Date())
    //Qui devi mettere Per Forza un Id e cioè del Bid Creator
    const [UserID, setUserID] = useState('1')
    const [astaImage, setAstaImage] = useState('')


    // Variabili Per l'Offerta
    const [offerta, setPrezzo] = useState([])
    const [userid, setUserIDuser] = useState(1)
    const [idasta, setAsta] = useState(2)


    useEffect(() => {

        const getSingleAstaData = async () => {
            const { data } = await axios.get(`/api/getAstaOfferta/${id}`)
            console.log(data)

            setTitle(data.title)
            setPrice(data.price)
            setAstaDescription(data.description)
            setPublished(data.published)
            setAstaImage(data.image)

            // Perl'Offerta
            setPrezzo(data.offerta)


        }
        getSingleAstaData()

    },[id])



    // Cancellare un Asta
    const handleDelete = async (id) => {
        await axios.delete(`/api/aste/${id}`)
        navigate('/aste')
    }

    // Aggiungere un Offerta

    const addOffertaHandler = async (e) => {

        e.preventDefault()

        let dofferta = {
            UserID: 1,
            AstaID: idasta,
            offerta: offerta,
        }
        
        //Aggiungi Offerta (MODIFCARE)
        await axios.post(`/api/aste/addOfferta/${id}/1`, dofferta)

        navigate('/aste') 
    }



    

    return (
        <>

        <Container className="mt-10 p-4">
        <h1 className="text-center">Dettaglio Asta</h1>
        <hr />

        <Row>
            <Col md={8} lg={8} sm={8}>
                <Card className='shadow-lg m-3 p-2 rounded'>
                        <Card.Img src={`http://localhost:3000/${astaImage}`} fluid />
                        <Card.Body>
                            <Card.Title>Title: {title}</Card.Title>
                            <Card.Title className="text-success">Offerta: €{price}</Card.Title>
                            <Card.Text>
                                Description: {astedescription}
                            </Card.Text>
                            <Card.Text>
                                Published: {published ? (<small>True</small>) : (<small>false</small>)}
                            </Card.Text>
                        <br />

                    
                            <Link to={`/aste/edit/${id}`}>
                                <Button>Modifica</Button>
                            </Link>
                            
                            <Button className="btn btn-danger m-2" onClick={() => handleDelete(id)}>Cancella</Button> 
                        
                    </Card.Body>        
                </Card>
            </Col>


                <Col md={4} lg={4} sm={4}>

                    <h2 className='text-center'>Offerta</h2>
                    <hr />

                        <Form onSubmit={addOffertaHandler}>
                            <Form.Group className="mb-3" controlId="offerta">
                                <Form.Label>Offerta</Form.Label>
                                <Form.Control
                                    value={offerta}
                                    onChange={(e) => setPrice(e.target.value)}
                                    type="number"
                                />
                            </Form.Group>

                        

                            <Form.Group className="mb-3" controlId="description">
                                <Form.Label>Tempo Rimanente</Form.Label>
                                <Form.Control
                                    value={bidTime}
                                    //onChange={(e) => setDescription(e.target.value)}
                                    as="textarea"
                                    />
                            </Form.Group>


                            <Button variant="primary" type="submit">
                                Offerta
                            </Button>
                        </Form>

                         <br />

                        <h5>Offerte Presentate</h5>
                        <hr />

                        {offerta.length > 0 ? (
                            offerta.map(offerta => {
                                return <p key={offerta.id}>Prezzo Offerta: {offerta.price} <br /> {}</p>
                            })
                        ): ( <p> Nessuna Offerta Fatta </p> )}

                        
                </Col>
        </Row>



                
        </Container>

       



        </>
    )
}

export default AstaDettaglio
