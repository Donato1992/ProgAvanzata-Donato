import Button from '@restart/ui/esm/Button'
import React from 'react'
import { Card } from 'react-bootstrap'
import { Link } from 'react-router-dom'

const AstaCard = ({ asta }) => {
    return (
        <>

            <Card className='shadow-lg m-2 p-3 rounded' style={{ width: '18rem' }}>
                <Card.Img src={asta.image} />
                <Card.Body>
                    <Card.Title>Titolo Asta: {asta.title}</Card.Title>
                    <Card.Title>Offerta: {asta.price}</Card.Title>
                    <Card.Text>
                        Description: {asta.description.slice(0,10)}...
                    </Card.Text>
                    <Card.Title>Tipo Asta: {asta.type}</Card.Title>
                    <Card.Title>Tempo Rimanente: {asta.BidTime}</Card.Title>
                 
                    <Link to={`/asta/${asta.id}`}>
                        <Button>Partecipa</Button>
                    </Link>
                </Card.Body>

                
               
            </Card>
       
           
        </>
    )
}

export default AstaCard
